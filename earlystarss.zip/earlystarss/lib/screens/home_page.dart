import 'dart:async';

import 'package:flutter/material.dart';
import 'package:earlystarss/screens/habits/habits_screen.dart';
import 'package:earlystarss/screens/profile/profile_screen.dart';
import 'package:earlystarss/screens/stats/stats_screen.dart';
import 'package:earlystarss/screens/timer/timer_screen.dart';
import 'package:earlystarss/models/habit.dart';
import 'package:earlystarss/models/session.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with SingleTickerProviderStateMixin {
  int _currentIndex = 0;
  int _statsViewIndex = 0; // New: For stats view selection (e.g., daily/weekly)
  List<Habit> _habits = [
    Habit(name: 'Study', isCompleted: false, streak: 5),
    Habit(name: 'Exercise', isCompleted: true, streak: 12),
    Habit(name: 'Read', isCompleted: false, streak: 2),
  ];
  List<Session> _sessions = [
    Session(activity: 'Math', durationMinutes: 25, date: DateTime.now().subtract(const Duration(hours: 2))),
    Session(activity: 'History', durationMinutes: 50, date: DateTime.now().subtract(const Duration(hours: 1))),
    Session(activity: 'Math', durationMinutes: 25, date: DateTime.now()),
  ];

  late final AnimationController _timerAnimationController;
  late Animation<double> _timerAnimation;
  late Timer _timer;
  int _totalSeconds = 1500; // 25 minutes
  int _initialSeconds = 1500; // Track initial for animation progress
  int _studyDuration = 1500;
  int _breakDuration = 300;
  bool _isStudySession = true;
  bool _isRunning = false;
  String _currentActivity = 'Untitled Session';
  int _elapsedSeconds = 0; // Track actual elapsed time

  @override
  void initState() {
    super.initState();
    _initialSeconds = _studyDuration;
    _timerAnimationController = AnimationController(
      vsync: this,
      duration: Duration(seconds: _totalSeconds),
    );
    _timerAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(_timerAnimationController); // 0 to 1 for progress
  }

  void _startTimer() {
    if (_isRunning) return;
    _isRunning = true;
    _elapsedSeconds = 0;
    _timerAnimationController.duration = Duration(seconds: _initialSeconds);
    _timerAnimationController.value = 0.0; // Start at empty
    _timerAnimationController.forward(); // Animate to 1.0 as time passes

    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (_totalSeconds > 0) {
        setState(() {
          _totalSeconds--;
          _elapsedSeconds++;
          // Sync animation value: progress = elapsed / initial (0 to 1)
          _timerAnimationController.value = _elapsedSeconds / _initialSeconds;
        });
      } else {
        _stopTimer(saveSession: _isStudySession); // Only save study sessions
        if (_isStudySession) {
          _totalSeconds = _breakDuration;
          _initialSeconds = _breakDuration;
        } else {
          _totalSeconds = _studyDuration;
          _initialSeconds = _studyDuration;
        }
        _isStudySession = !_isStudySession;
        // TODO: Show dialog for auto-start confirmation
        // _startTimer(); // Commented to prevent auto-start
      }
    });
  }

  void _stopTimer({bool saveSession = false}) {
    if (_isRunning) {
      _timer.cancel();
      _isRunning = false;
      _timerAnimationController.stop();
      if (saveSession) {
        setState(() {
          _sessions.add(Session(
            activity: _currentActivity,
            durationMinutes: _elapsedSeconds ~/ 60, // Use actual elapsed
            date: DateTime.now(),
          ));
        });
      }
    }
  }

  void _resetTimer() {
    _stopTimer();
    setState(() {
      _isStudySession = true;
      _totalSeconds = _studyDuration;
      _initialSeconds = _studyDuration;
      _elapsedSeconds = 0;
      _timerAnimationController.value = 0.0;
    });
  }

  void _skipSession() {
    _stopTimer(saveSession: _isStudySession);
    setState(() {
      _isStudySession = !_isStudySession;
      _totalSeconds = _isStudySession ? _studyDuration : _breakDuration;
      _initialSeconds = _totalSeconds;
      _elapsedSeconds = 0;
      _timerAnimationController.value = 0.0;
    });
  }

  void _handleHabitTapped(int index) {
    setState(() {
      final habit = _habits[index];
      habit.isCompleted = !habit.isCompleted;
      if (habit.isCompleted) {
        habit.streak++;
      } else {
        habit.streak = 0;
      }
    });
  }

  void _addHabit(String name) {
    if (name.trim().isEmpty) return; // Basic validation
    setState(() {
      _habits.add(Habit(name: name, isCompleted: false, streak: 0));
    });
  }

  void _deleteHabit(int index) {
    setState(() {
      _habits.removeAt(index);
    });
  }

  void _selectPreset(int studyMins, int breakMins) {
    _stopTimer();
    setState(() {
      _studyDuration = studyMins * 60;
      _breakDuration = breakMins * 60;
      _isStudySession = true;
      _totalSeconds = _studyDuration;
      _initialSeconds = _studyDuration;
      _elapsedSeconds = 0;
      _timerAnimationController.duration = Duration(seconds: _totalSeconds);
      _timerAnimationController.value = 0.0;
    });
  }

  void _nameSession() {
    TextEditingController controller = TextEditingController(text: _currentActivity);
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Name this session'),
        content: TextField(
          controller: controller,
          decoration: const InputDecoration(labelText: 'Activity Name'),
        ),
        actions: [
          TextButton(
            onPressed: () {
              setState(() {
                _currentActivity = controller.text;
              });
              Navigator.of(context).pop();
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );
  }

  // New: Callback for stats view changes
  void _onStatsViewChange(int newIndex) {
    setState(() {
      _statsViewIndex = newIndex;
    });
  }

  @override
  void dispose() {
    _timer.cancel();
    _timerAnimationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: _currentIndex,
        children: [
          TimerScreen(
            totalSeconds: _totalSeconds,
            isStudySession: _isStudySession,
            isRunning: _isRunning,
            currentActivity: _currentActivity,
            studyDuration: _studyDuration,
            breakDuration: _breakDuration,
            animation: _timerAnimation,
            onStart: _startTimer,
            onPause: () => _stopTimer(),
            onReset: _resetTimer,
            onSkip: _skipSession,
            onSelectPreset: _selectPreset,
            onNameSession: _nameSession,
          ),
          HabitsScreen(
            habits: _habits,
            onHabitTapped: _handleHabitTapped,
            onAddHabit: _addHabit,
            onDeleteHabit: _deleteHabit,
          ),
          StatsScreen(
            sessions: _sessions,
            statsViewIndex: _statsViewIndex, // Fixed: Provide required param
            onStatsViewChange: _onStatsViewChange, // Fixed: Provide required callback
          ),
          const ProfileScreen(),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: (index) {
          setState(() {
            _currentIndex = index;
          });
        },
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.timer),
            label: 'Timer',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.check_circle_outline),
            label: 'Habits',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.bar_chart),
            label: 'Stats',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: 'Profile',
          ),
        ],
      ),
    );
  }
}