import 'package:flutter/material.dart';
import 'package:earlystarss/models/session.dart';

class StatsScreen extends StatelessWidget {
  final List<Session> sessions;
  final int statsViewIndex;
  final Function(int) onStatsViewChange;

  const StatsScreen({
    Key? key,
    required this.sessions,
    required this.statsViewIndex,
    required this.onStatsViewChange,
  }) : super(key: key);

  Widget _buildStatsTabButton(int index, String title) {
    return Builder(
      builder: (BuildContext context) {
        bool isSelected = statsViewIndex == index;
        return ElevatedButton(
          onPressed: () => onStatsViewChange(index),
          style: ElevatedButton.styleFrom(
            foregroundColor: isSelected ? Colors.white : Theme.of(context).colorScheme.onSurface,
            backgroundColor: isSelected ? Theme.of(context).colorScheme.primary : Theme.of(context).colorScheme.surface,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          ),
          child: Text(title),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final Map<String, int> subjectTime = {};
    for (var session in sessions) {
      subjectTime.update(
          session.activity, (value) => value + session.durationMinutes,
          ifAbsent: () => session.durationMinutes);
    }
    final totalTime = subjectTime.values.fold(0, (sum, item) => sum + item);

    return SingleChildScrollView(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Your Progress',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Theme.of(context).colorScheme.onSurface,
              ),
            ),
            const SizedBox(height: 10),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _buildStatsTabButton(0, 'Daily'),
                _buildStatsTabButton(1, 'Weekly'),
                _buildStatsTabButton(2, 'Monthly'),
              ],
            ),
            const SizedBox(height: 20),
            Card(
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              elevation: 4,
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '${['Daily', 'Weekly', 'Monthly'][statsViewIndex]} Focus Time',
                      style: Theme.of(context).textTheme.titleLarge,
                    ),
                    const SizedBox(height: 10),
                    Container(
                      height: 150,
                      decoration: BoxDecoration(
                        color: Theme.of(context).colorScheme.surface,
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: const Center(
                        child: Text(
                          'Placeholder for a Bar Chart',
                          style: TextStyle(color: Colors.grey),
                        ),
                      ),
                    ),
                    const SizedBox(height: 10),
                    Text(
                      'Total: $totalTime minutes',
                      style: Theme.of(context).textTheme.bodyMedium,
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),
            Text(
              'Focus by Subject',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Theme.of(context).colorScheme.onSurface,
              ),
            ),
            const SizedBox(height: 10),
            if (totalTime > 0)
              ...subjectTime.entries.map((entry) {
                return Padding(
                  padding: const EdgeInsets.symmetric(vertical: 8.0),
                  child: Row(
                    children: [
                      Expanded(
                        flex: 3,
                        child: Text(
                          entry.key,
                          style: Theme.of(context).textTheme.bodyMedium,
                        ),
                      ),
                      Expanded(
                        flex: 2,
                        child: LinearProgressIndicator(
                          value: entry.value / totalTime,
                          backgroundColor: Theme.of(context).colorScheme.surface,
                          valueColor: AlwaysStoppedAnimation<Color>(Theme.of(context).colorScheme.primary),
                          minHeight: 10,
                        ),
                      ),
                      const SizedBox(width: 10),
                      Text('${entry.value} min'),
                    ],
                  ),
                );
              }).toList(),
            if (totalTime == 0)
              Center(
                child: Text(
                  "Start a session to see your stats!",
                  style: TextStyle(fontStyle: FontStyle.italic, color: Theme.of(context).colorScheme.onSurface.withOpacity(0.5)),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
