import 'package:flutter/material.dart';
import 'package:earlystarss/models/habit.dart';

class HabitsScreen extends StatelessWidget {
  final List<Habit> habits;
  final Function(int) onHabitTapped;
  final Function(String) onAddHabit;
  final Function(int) onDeleteHabit;

  const HabitsScreen({
    Key? key,
    required this.habits,
    required this.onHabitTapped,
    required this.onAddHabit,
    required this.onDeleteHabit,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Habit Tracker'),
        centerTitle: true,
      ),
      body: ListView.builder(
        itemCount: habits.length,
        itemBuilder: (context, index) {
          final habit = habits[index];
          return ListTile(
            leading: IconButton(
              icon: Icon(
                habit.isCompleted
                    ? Icons.check_box_rounded
                    : Icons.check_box_outline_blank_rounded,
              ),
              onPressed: () => onHabitTapped(index),
            ),
            title: Text(
              habit.name,
              style: TextStyle(
                decoration: habit.isCompleted ? TextDecoration.lineThrough : null,
              ),
            ),
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text('Streak: ${habit.streak}'),
                IconButton(
                  icon: const Icon(Icons.delete),
                  onPressed: () => onDeleteHabit(index),
                ),
              ],
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          _showAddHabitDialog(context);
        },
        child: const Icon(Icons.add),
      ),
    );
  }

  void _showAddHabitDialog(BuildContext context) {
    TextEditingController controller = TextEditingController();
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Add New Habit'),
        content: TextField(
          controller: controller,
          decoration: const InputDecoration(hintText: 'Enter habit name'),
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
            },
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              if (controller.text.isNotEmpty) {
                onAddHabit(controller.text);
              }
              Navigator.of(context).pop();
            },
            child: const Text('Add'),
          ),
        ],
      ),
    );
  }
}
