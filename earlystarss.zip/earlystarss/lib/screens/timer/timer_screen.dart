import 'package:flutter/material.dart';
import 'dart:async';

class TimerScreen extends StatelessWidget {
  final int totalSeconds;
  final bool isStudySession;
  final bool isRunning;
  final String currentActivity;
  final int studyDuration;
  final int breakDuration;
  final Animation<double> animation;
  final VoidCallback onStart;
  final VoidCallback onPause;
  final VoidCallback onReset;
  final VoidCallback onSkip;
  final Function(int, int) onSelectPreset;
  final VoidCallback onNameSession;

  const TimerScreen({
    Key? key,
    required this.totalSeconds,
    required this.isStudySession,
    required this.isRunning,
    required this.currentActivity,
    required this.studyDuration,
    required this.breakDuration,
    required this.animation,
    required this.onStart,
    required this.onPause,
    required this.onReset,
    required this.onSkip,
    required this.onSelectPreset,
    required this.onNameSession,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final minutes = (totalSeconds ~/ 60).toString().padLeft(2, '0');
    final seconds = (totalSeconds % 60).toString().padLeft(2, '0');

    Widget _buildPresetButton(String title, int studyMins, int breakMins) {
      bool isSelected = studyDuration ~/ 60 == studyMins;
      return ElevatedButton(
        onPressed: () => onSelectPreset(studyMins, breakMins),
        style: ElevatedButton.styleFrom(
          foregroundColor: isSelected ? Colors.white : Theme.of(context).colorScheme.onSurface,
          backgroundColor: isSelected ? Theme.of(context).colorScheme.primary : Theme.of(context).colorScheme.surface,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        ),
        child: Text(title),
      );
    }

    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          GestureDetector(
            onTap: onNameSession,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  currentActivity,
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Theme.of(context).colorScheme.primary,
                  ),
                ),
                const Icon(Icons.edit, size: 20, color: Color(0xFFF9A825)),
              ],
            ),
          ),
          const SizedBox(height: 20),
          Stack(
            alignment: Alignment.center,
            children: [
              SizedBox(
                width: 250,
                height: 250,
                child: AnimatedBuilder(
                  animation: animation,
                  builder: (context, child) {
                    return CircularProgressIndicator(
                      value: animation.value,
                      strokeWidth: 10,
                      backgroundColor: Theme.of(context).colorScheme.surface,
                      valueColor: AlwaysStoppedAnimation<Color>(
                        Theme.of(context).colorScheme.primary,
                      ),
                    );
                  },
                ),
              ),
              Column(
                children: [
                  Text(
                    isStudySession ? "FOCUS" : "BREAK",
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: Theme.of(context).colorScheme.onSurface,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    '$minutes:$seconds',
                    style: TextStyle(
                      fontSize: 48,
                      fontWeight: FontWeight.bold,
                      color: Theme.of(context).colorScheme.primary,
                    ),
                  ),
                  const SizedBox(height: 16),
                  Text(
                    "You've got this!",
                    style: TextStyle(
                      fontSize: 16,
                      fontStyle: FontStyle.italic,
                      color: Theme.of(context).colorScheme.onSurface,
                    ),
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: 40),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              IconButton(
                onPressed: isRunning ? onPause : onStart,
                iconSize: 64,
                color: Theme.of(context).colorScheme.primary,
                icon: Icon(isRunning ? Icons.pause_circle_filled : Icons.play_circle_filled),
              ),
              const SizedBox(width: 20),
              IconButton(
                onPressed: onReset,
                iconSize: 48,
                color: Theme.of(context).colorScheme.onSurface,
                icon: const Icon(Icons.refresh),
              ),
              const SizedBox(width: 20),
              IconButton(
                onPressed: onSkip,
                iconSize: 48,
                color: Theme.of(context).colorScheme.onSurface,
                icon: const Icon(Icons.skip_next),
              ),
            ],
          ),
          const SizedBox(height: 30),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              _buildPresetButton('Pomodoro', 25, 5),
              const SizedBox(width: 10),
              _buildPresetButton('Deep Work', 50, 10),
            ],
          ),
        ],
      ),
    );
  }
}
