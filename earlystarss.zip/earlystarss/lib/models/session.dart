class Session {
  String activity;
  int durationMinutes;
  DateTime date;

  Session({required this.activity, required this.durationMinutes, required this.date});
}
