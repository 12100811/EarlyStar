class Habit {
  String name;
  bool isCompleted;
  int streak;

  Habit({required this.name, this.isCompleted = false, this.streak = 0});
}
