import 'package:flutter/material.dart';

class TimerRing extends StatelessWidget {
  final int totalSeconds;
  final Animation<double> animation;
  final bool isStudySession;

  const TimerRing({
    Key? key,
    required this.totalSeconds,
    required this.animation,
    required this.isStudySession,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final minutes = (totalSeconds ~/ 60).toString().padLeft(2, '0');
    final seconds = (totalSeconds % 60).toString().padLeft(2, '0');

    return Stack(
      alignment: Alignment.center,
      children: [
        SizedBox(
          width: 250,
          height: 250,
          child: AnimatedBuilder(
            animation: animation,
            builder: (context, child) {
              return CircularProgressIndicator(
                value: animation.value,
                strokeWidth: 10,
                backgroundColor: Theme.of(context).colorScheme.surface,
                valueColor: AlwaysStoppedAnimation<Color>(
                  Theme.of(context).colorScheme.primary,
                ),
              );
            },
          ),
        ),
        Column(
          children: [
            Text(
              isStudySession ? "FOCUS" : "BREAK",
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Theme.of(context).colorScheme.onSurface,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              '$minutes:$seconds',
              style: TextStyle(
                fontSize: 48,
                fontWeight: FontWeight.bold,
                color: Theme.of(context).colorScheme.primary,
              ),
            ),
            const SizedBox(height: 16),
            Text(
              "You've got this!",
              style: TextStyle(
                fontSize: 16,
                fontStyle: FontStyle.italic,
                color: Theme.of(context).colorScheme.onSurface,
              ),
            ),
          ],
        ),
      ],
    );
  }
}
