import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';

class GoogleSignInButton extends StatelessWidget {
  const GoogleSignInButton({super.key});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 50,
      width: 280,
      child: ElevatedButton(
        onPressed: () async {
          try {
            final GoogleSignInAccount? googleUser = await GoogleSignIn().signIn();
            if (googleUser != null) {
              final GoogleSignInAuthentication googleAuth = await googleUser.authentication;
              final credential = GoogleAuthProvider.credential(
                accessToken: googleAuth.accessToken,
                idToken: googleAuth.idToken,
              );
              await FirebaseAuth.instance.signInWithCredential(credential);
              // Handle successful sign-in
              print('Successfully signed in: ${googleUser.displayName}');
            }
          } catch (e) {
            print('Sign-in error: $e');
            // Handle error
          }
        },
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.white,
          foregroundColor: Colors.black87,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(30), // Rounded edges
            side: const BorderSide(color: Colors.grey), // subtle border
          ),
          elevation: 2,
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.asset(
              "assets/images/logogoogle.png", // Updated path
              height: 24,
              width: 24,
            ),
          ],
        ),
      ),
    );
  }
}